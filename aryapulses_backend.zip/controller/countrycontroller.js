const Country = require("../models/country");

// Create Country
exports.createCountry = async (req, res) => {
  try {
    const newCountry = new Country(req.body);
    const saved = await newCountry.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get All Countries (with pagination + search + filter)
exports.getAllCountries = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search = "",
      countryName = "",
      countryCode = ""
    } = req.query;

    const query = {
      ...(countryName && { countryName: { $regex: countryName, $options: "i" } }),
      ...(countryCode && { countryCode: { $regex: countryCode, $options: "i" } }),
      ...(search && {
        $or: [
          { countryName: { $regex: search, $options: "i" } },
          { countryCode: { $regex: search, $options: "i" } }
        ]
      }),
    };

    const total = await Country.countDocuments(query);
    const country = await Country.find(query)
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });

    res.json({ country, total });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get Country by ID
exports.getCountryById = async (req, res) => {
  try {
    const country = await Country.findById(req.params.id);
    if (!country) return res.status(404).json({ message: "Country not found" });
    res.json(country);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Update Country
exports.updateCountry = async (req, res) => {
  try {
    const updated = await Country.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updated) return res.status(404).json({ message: "Country not found" });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Delete Country
exports.deleteCountry = async (req, res) => {
  try {
    const deleted = await Country.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: "Country not found" });
    res.json({ message: "Country deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
