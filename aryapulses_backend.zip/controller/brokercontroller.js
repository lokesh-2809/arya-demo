const Broker = require('../models/broker');

// GET all brokers with pagination and filtering
exports.getBrokers = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 50,
      brokerId,
      brokerName,
      phoneContact,
      emailContact,
      streetAddress,
      state,
      postcode,
      country,
      typeOfReferral,
      status,
    } = req.query;

    const query = {};

    if (brokerId) query.brokerId = { $regex: brokerId, $options: 'i' };
    if (brokerName) query.brokerName = { $regex: brokerName, $options: 'i' };
    if (phoneContact) query.phoneContact = { $regex: phoneContact, $options: 'i' };
    if (emailContact) query.emailContact = { $regex: emailContact, $options: 'i' };
    if (streetAddress) query.streetAddress = { $regex: streetAddress, $options: 'i' };
    if (state) query.state = { $regex: state, $options: 'i' };
    if (postcode) query.postcode = { $regex: postcode, $options: 'i' };
    if (country) query.country = { $regex: country, $options: 'i' };
    if (typeOfReferral) query.typeOfReferral = { $regex: typeOfReferral, $options: 'i' };
    if (status) query.status = { $regex: status, $options: 'i' };

    const brokers = await Broker.find(query)
      .skip((parseInt(page) - 1) * parseInt(limit))
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });

    const total = await Broker.countDocuments(query);

    res.status(200).json({ brokers, total });
  } catch (err) {
    console.error('Error fetching brokers:', err);
    res.status(500).json({ error: 'Failed to fetch brokers', details: err.message });
  }
};

// POST create a new broker
exports.createBroker = async (req, res) => {
  try {
    const newBroker = new Broker(req.body);
    await newBroker.save();
    res.status(201).json({ message: 'Broker created', broker: newBroker });
  } catch (err) {
    console.error('Error creating broker:', err);
    res.status(500).json({ error: 'Failed to create broker', details: err.message });
  }
};

// GET broker by ID
exports.getBrokerById = async (req, res) => {
  try {
    const broker = await Broker.findById(req.params.id);
    if (!broker) return res.status(404).json({ error: 'Broker not found' });
    res.json(broker);
  } catch (err) {
    console.error('Error fetching broker by ID:', err);
    res.status(500).json({ error: 'Failed to fetch broker', details: err.message });
  }
};

// PUT update broker
exports.updateBroker = async (req, res) => {
  try {
    const updated = await Broker.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!updated) return res.status(404).json({ error: 'Broker not found' });
    res.json({ message: 'Broker updated', broker: updated });
  } catch (err) {
    console.error('Error updating broker:', err);
    res.status(500).json({ error: 'Failed to update broker', details: err.message });
  }
};

// DELETE broker
exports.deleteBroker = async (req, res) => {
  try {
    const deleted = await Broker.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ error: 'Broker not found' });
    res.json({ message: 'Broker deleted' });
  } catch (err) {
    console.error('Error deleting broker:', err);
    res.status(500).json({ error: 'Failed to delete broker', details: err.message });
  }
};