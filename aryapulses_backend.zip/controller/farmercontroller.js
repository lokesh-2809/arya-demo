// backend/farmerController.js
import Farmer from "../models/farmer.js";

export async function createFarmer(req, res) {
  try {
    const farmer = await Farmer.create(req.body);
    res.status(201).json(farmer);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function getFarmers(req, res) {
  try {
    const {
      page = 1,
      limit = 10,
      search = "",
      ...filters
    } = req.query;

    const query = {};

    // Global search
    if (search) {
      query.farmerName = { $regex: search, $options: "i" };
    }

    // Field-level filters
    Object.entries(filters).forEach(([key, value]) => {
      if (value && key !== "search") {
        query[key] = { $regex: value, $options: "i" };
      }
    });

    const total = await Farmer.countDocuments(query);
    const farmers = await Farmer.find(query)
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .sort({ createdAt: -1 });

    res.json({ total, farmers });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function getFarmerById(req, res) {
  try {
    const farmer = await Farmer.findById(req.params.id);
    if (!farmer) return res.status(404).json({ message: "Not found" });
    res.json(farmer);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function updateFarmer(req, res) {
  try {
    const updated = await Farmer.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updated) return res.status(404).json({ message: "Not found" });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function deleteFarmer(req, res) {
  try {
    await Farmer.findByIdAndDelete(req.params.id);
    res.json({ message: "Deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
