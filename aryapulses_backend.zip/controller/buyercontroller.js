const Buyer = require("../models/buyer");

// Create
const createBuyer = async (req, res) => {
  try {
    const buyer = await Buyer.create(req.body);
    res.status(201).json(buyer);
  } catch (error) {
    res.status(500).json({ message: "Error creating buyer", error });
  }
};

// Get buyers (global search + filters + pagination)
const getBuyers = async (req, res) => {
  try {
    const { page = 1, limit = 10, search = "", ...filters } = req.query;

    const queryParts = [];

    if (search) {
      queryParts.push({ buyerName: { $regex: search, $options: "i" } });
    }

    Object.entries(filters).forEach(([k, v]) => {
      if (v) queryParts.push({ [k]: { $regex: v, $options: "i" } });
    });

    const query = queryParts.length ? { $and: queryParts } : {};

    const total = await Buyer.countDocuments(query);
    const buyers = await Buyer.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * parseInt(limit))
      .limit(parseInt(limit));

    res.json({ buyers, total });
  } catch (error) {
    res.status(500).json({ message: "Error fetching buyers", error });
  }
};

// Get buyer by ID
const getBuyerById = async (req, res) => {
  try {
    const buyer = await Buyer.findById(req.params.id);
    if (!buyer) return res.status(404).json({ message: "Buyer not found" });
    res.json(buyer);
  } catch (error) {
    res.status(500).json({ message: "Error fetching buyer", error });
  }
};

// Update buyer
const updateBuyer = async (req, res) => {
  try {
    const updated = await Buyer.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: "Error updating buyer", error });
  }
};

// Delete buyer
const deleteBuyer = async (req, res) => {
  try {
    await Buyer.findByIdAndDelete(req.params.id);
    res.json({ message: "Buyer deleted" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting buyer", error });
  }
};

// Export all controllers
module.exports = {
  createBuyer,
  getBuyers,
  getBuyerById,
  updateBuyer,
  deleteBuyer
};
